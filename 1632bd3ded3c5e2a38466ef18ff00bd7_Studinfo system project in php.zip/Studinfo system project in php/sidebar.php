

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav" style="background-image: linear-gradient(#009999, #014923);">
        <li class="nav-item">
          <a class="nav-link"href="index.php">
            <i class="fas fa-fw fa-home"></i>
            <span> HOMEPAGE</span>
          </a>
        </li>
       <!--<li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw  fa-cloud"></i>
            <span>SERVICES</span>
         </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item " href="urns.php">URNS</a> 
            <a class="dropdown-item " href="caskets.php">CASKETS</a>
            <a class="dropdown-item " href="vehicles.php">VEHICLES</a>
          </div>-->
        </li>
        <li class="nav-item">
          <a class="nav-link" href="student.php">
            <i class="fas fa-fw fa-users  "></i>
            <span style="text-shadow: 0px 1px 5px black;">STUDENT</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="course.php">
            <i class="fas fa-fw fa-users    "></i>
            <span style="text-shadow: 0px 1px 5px black;">COURSE</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="section.php">
            <i class="fas fa-fw fa-user  "></i>
            <span style="text-shadow: 0px 1px 5px black;">SECTION</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="enrollment.php">
            <i class="fas fa-fw fa-fill  "></i>
            <span style="text-shadow: 0px 1px 5px black;">Enrollment</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="schedule.php">
            <i class="fas fa-fw fa-clock  "></i>
            <span style="text-shadow: 0px 1px 5px black;">Schedule</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="level.php">
            <i class="fas fa-fw fa-book  "></i>
            <span style="text-shadow: 0px 1px 5px black;">Year Level</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="status.php">
            <i class="fas fa-fw fa-user  "></i>
            <span style="text-shadow: 0px 1px 5px black;">Status</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">